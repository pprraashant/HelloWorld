SoapUI ext folder; place external jars that should be added to SoapUI classpath here,
for example JDBC drivers, custom libraries, etc..

Good Luck!